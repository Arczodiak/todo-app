package com.example.todo.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.todo.models.User
import com.example.todo.models.Task

@Database(entities = [User::class, Task::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun taskDao(): TaskDao
}
