package com.example.todo

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.todo.database.AppDatabase
import com.example.todo.database.UserDao
import com.example.todo.database.TaskDao
import com.example.todo.models.User
import com.example.todo.models.Task

class MainActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var userDao: UserDao
    private lateinit var taskDao: TaskDao
    private var loggedInUser: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the database and DAOs
        db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "todo-db").build()
        userDao = db.userDao()
        taskDao = db.taskDao()

        val usernameField: EditText = findViewById(R.id.username)
        val passwordField: EditText = findViewById(R.id.password)
        val taskTitleField: EditText = findViewById(R.id.taskTitle)
        val taskDescriptionField: EditText = findViewById(R.id.taskDescription)
        val taskList: ListView = findViewById(R.id.taskList)

        val registerBtn: Button = findViewById(R.id.registerBtn)
        val loginBtn: Button = findViewById(R.id.loginBtn)
        val addTaskBtn: Button = findViewById(R.id.addTaskBtn)

        // Register button click handler
        registerBtn.setOnClickListener {
            val username = usernameField.text.toString()
            val password = passwordField.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                // Register user in background thread
                GlobalScope.launch(Dispatchers.IO) {
                    val user = User(username = username, password = password)
                    userDao.insertUser(user)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, "User registered!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        // Login button click handler
        loginBtn.setOnClickListener {
            val username = usernameField.text.toString()
            val password = passwordField.text.toString()

            GlobalScope.launch(Dispatchers.IO) {
                val user = userDao.login(username, password)  // Ensure `login` is defined in `UserDao`
                withContext(Dispatchers.Main) {
                    if (user != null) {
                        loggedInUser = username
                        loadTasks(taskList)
                        Toast.makeText(this@MainActivity, "Login successful!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, "Invalid credentials.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        // Add task button click handler
        addTaskBtn.setOnClickListener {
            if (loggedInUser != null) {
                val title = taskTitleField.text.toString()
                val description = taskDescriptionField.text.toString()

                GlobalScope.launch(Dispatchers.IO) {
                    val task = Task(id = 0, username = loggedInUser!!, title = title, description = description)
                    taskDao.insertTask(task)
                    withContext(Dispatchers.Main) {
                        loadTasks(taskList)
                        Toast.makeText(this@MainActivity, "Task added!", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "Please log in first.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Load tasks for the logged-in user
    private fun loadTasks(taskList: ListView) {
        loggedInUser?.let { user ->
            GlobalScope.launch(Dispatchers.IO) {
                val tasks = taskDao.getTasksForUser(user)
                val taskTitles = tasks.map { "${it.title}: ${it.description}" }
                withContext(Dispatchers.Main) {
                    val adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, taskTitles)
                    taskList.adapter = adapter
                }
            }
        }
    }
}
