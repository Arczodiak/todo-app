package com.example.todo.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.todo.models.Task

@Dao
interface TaskDao {
    @Insert
    suspend fun insertTask(task: Task)

    @Query("SELECT * FROM tasks WHERE username = :username")
    suspend fun getTasksForUser(username: String): List<Task>
}
